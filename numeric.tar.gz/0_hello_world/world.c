#include <stdio.h>
void world()
{
	printf("World!\n");
	return;
}
