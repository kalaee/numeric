void hello();
void world();

int main()
{
	hello();
	world();
	return 0;
}
