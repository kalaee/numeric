#include <stdio.h>
void hello()
{
	printf("Hello, ");
	return;
}
