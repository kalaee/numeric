#include <assert.h>
#include <stdio.h>

double lspline(int n, double x[], double y[], double z);
