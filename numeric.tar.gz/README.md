# numeric
Code for the course [Numerical Methods][course] 2015 at Aarhus University.

[course]: http://owww.phys.au.dk/~fedorov/Numeric/now/home.php "Course page"
